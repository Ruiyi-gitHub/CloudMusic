create view view_cardinfo as
    /* ALGORITHM=UNDEFINED */
select `bankdb`.`bankcarinfo`.`bankCarNum`    AS `卡号`,
       `bankdb`.`bankuser`.`userName`         AS `姓名`,
       `bankdb`.`bankcarinfo`.`MoneyType`     AS `币种`,
       `bankdb`.`moneygoout`.`oType`          AS `存款类型`,
       `bankdb`.`bankcarinfo`.`userStatrDate` AS `开户日期`,
       `bankdb`.`bankcarinfo`.`CarYe`         AS `存款余额`,
       `bankdb`.`bankcarinfo`.`bankPwd`       AS `密码`,
       `bankdb`.`bankyngs`.`gsType`           AS `账户状态`
from (((`bankdb`.`bankcarinfo` join `bankdb`.`bankuser` on ((`bankdb`.`bankcarinfo`.`bCarMan` = `bankdb`.`bankuser`.`bUserID`))) join `bankdb`.`moneygoout` on ((`bankdb`.`moneygoout`.`oID` = `bankdb`.`bankcarinfo`.`cMoneyType`)))
         join `bankdb`.`bankyngs` on ((`bankdb`.`bankyngs`.`gsID` = `bankdb`.`bankcarinfo`.`CarYnGS`)));

