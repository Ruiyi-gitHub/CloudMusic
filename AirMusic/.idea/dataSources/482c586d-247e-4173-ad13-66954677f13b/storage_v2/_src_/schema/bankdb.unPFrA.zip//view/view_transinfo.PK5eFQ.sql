create view view_transinfo as
    /* ALGORITHM=UNDEFINED */
select `bankdb`.`bankjy`.`jDate`           AS `交易日期`,
       `bankdb`.`bankjy`.`jType`           AS `客户`,
       `bankdb`.`bankcarinfo`.`bankCarNum` AS `卡号`,
       `bankdb`.`bankjy`.`jMoney`          AS `交易金额`,
       `bankdb`.`bankjy`.`jComment`        AS `备注`
from (`bankdb`.`bankjy`
         join `bankdb`.`bankcarinfo` on ((`bankdb`.`bankcarinfo`.`bCarID` = `bankdb`.`bankjy`.`bCarID`)));

