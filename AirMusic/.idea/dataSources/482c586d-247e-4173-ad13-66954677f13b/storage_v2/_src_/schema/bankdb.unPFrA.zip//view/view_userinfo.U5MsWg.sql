create view view_userinfo as
    /* ALGORITHM=UNDEFINED */
select `bankdb`.`bankuser`.`bUserID`    AS `客户编号`,
       `bankdb`.`bankuser`.`userName`   AS `开户名`,
       `bankdb`.`bankuser`.`userCarNum` AS `身份证号`,
       `bankdb`.`bankuser`.`userPhone`  AS `电话号码`,
       `bankdb`.`bankuser`.`userAddres` AS `居住地址`
from `bankdb`.`bankuser`;

