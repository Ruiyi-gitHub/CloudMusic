create procedure attach(IN in_debug_id INTEGER(10))
BEGIN
  SET @debug_id = in_debug_id, @timeout = 5;
  DO GET_LOCK(@debug_id, 5);
END;

