create function check_breakpoint() returns INT(10)
BEGIN
  DECLARE result INTEGER DEFAULT 0;

  IF (@debug_id > 0) THEN
    SELECT COUNT(*) FROM callstack c, breakpoints b
      WHERE c.debug_id = @debug_id AND b.debug_id = @debug_id AND c.stack_depth = @stack_depth AND 
        c.module_name = b.module_name AND c.module_owner = b.module_owner AND c.module_type = b.module_type AND 
        c.start_line = b.line /*AND 
        c.StartPos = b.Pos*/
      INTO result;
  END IF;
  RETURN result;
END;

