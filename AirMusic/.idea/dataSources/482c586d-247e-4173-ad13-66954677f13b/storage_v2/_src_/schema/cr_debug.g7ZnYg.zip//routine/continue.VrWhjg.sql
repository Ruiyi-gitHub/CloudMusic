create procedure `continue`(IN in_step_kind INTEGER(10))
BEGIN
  DECLARE stack_depth INTEGER;

  DECLARE second_lock VARCHAR(200);

  SELECT MAX(c.stack_depth) FROM callstack c WHERE c.debug_id = @debug_id INTO stack_depth;

  UPDATE debuggings SET step_kind = in_step_kind WHERE id = @debug_id; 

  IF (in_step_kind = 3) THEN
    UPDATE debuggings SET estimated_depth = stack_depth - 1 WHERE id = @debug_id;
  ELSEIF (in_step_kind = 2) THEN
    UPDATE debuggings SET estimated_depth = stack_depth WHERE id = @debug_id;
  ELSE
    UPDATE debuggings SET estimated_depth = -1 WHERE ID = @debug_id;
  END IF;

  IF (IS_USED_LOCK(@debug_id) = CONNECTION_ID()) THEN
    SET second_lock = CONCAT(@debug_id, 'second');
  ELSE
    SET second_lock = @debug_id;
  END IF;

  DO GET_LOCK(second_lock, 10);
END;

