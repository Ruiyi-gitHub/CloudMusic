create procedure debug_off()
BEGIN  
  DELETE FROM callstack WHERE debug_id = @debug_id;
  DELETE FROM breakpoints WHERE debug_id = @debug_id;
  DELETE FROM watches WHERE debug_id = @debug_id;
  DELETE FROM debuggings WHERE id = @debug_id;
  DELETE FROM info WHERE debug_id = @debug_id;
  DO RELEASE_LOCK(CONCAT(@debug_id, 'secondary'));
END;

