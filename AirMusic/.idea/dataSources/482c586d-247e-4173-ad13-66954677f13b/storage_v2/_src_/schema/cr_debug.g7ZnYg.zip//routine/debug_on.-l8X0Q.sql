create procedure debug_on(IN out_debug_id INTEGER(10))
BEGIN
  CALL update_system_calls(-1);
  
  DELETE d.*, c.*, i.*, w.*, b.* FROM debuggings d 
    LEFT JOIN callstack c ON c.debug_id = d.id
    LEFT JOIN breakpoints b ON b.debug_id = d.id
    LEFT JOIN info i ON i.debug_id = d.id
    LEFT JOIN watches w ON w.debug_id = d.id 
  WHERE proc_id = CONNECTION_ID();

  INSERT INTO debuggings (proc_id, step_kind) VALUES (CONNECTION_ID(), 1);
  SELECT LAST_INSERT_ID() INTO @debug_id;

  SET @stack_depth := 0;

  INSERT INTO info (debug_id, break_reason, stack_depth) VALUES (@debug_id, -1, @stack_depth);

  SET out_debug_id := @debug_id;
END;

