create procedure detach()
BEGIN
  DO RELEASE_LOCK(@debug_id);
  SET @debug_id = -1;
END;

