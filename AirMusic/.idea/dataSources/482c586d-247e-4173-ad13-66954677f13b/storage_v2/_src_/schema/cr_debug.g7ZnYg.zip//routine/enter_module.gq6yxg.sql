create function enter_module(in_module_name VARCHAR(300), in_module_owner VARCHAR(300),
                             in_module_type INTEGER(10)) returns INT(10)
BEGIN
  IF (@debug_id > 0) THEN
    SET @stack_depth := @stack_depth + 1;
    UPDATE info SET stack_depth = @stack_depth WHERE debug_id = @debug_id;
    INSERT INTO callstack (debug_id, module_name, module_owner, module_type, stack_depth) 
      VALUES (@debug_id, in_module_name, in_module_owner, in_module_type, @stack_depth);
  END IF;

  RETURN @stack_depth;
END;

