create function get_found_rows() returns INT(10)
BEGIN
  RETURN @debug_found_rows;
END;

