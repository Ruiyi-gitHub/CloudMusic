create function get_last_insert_id() returns INT(10)
BEGIN
  RETURN @debug_last_insert_id;
END;

