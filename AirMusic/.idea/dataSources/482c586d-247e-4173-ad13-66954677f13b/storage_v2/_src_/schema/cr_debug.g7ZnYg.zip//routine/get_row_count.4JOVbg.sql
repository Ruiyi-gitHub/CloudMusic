create function get_row_count() returns INT(10)
BEGIN
  RETURN @debug_row_count;
END;

