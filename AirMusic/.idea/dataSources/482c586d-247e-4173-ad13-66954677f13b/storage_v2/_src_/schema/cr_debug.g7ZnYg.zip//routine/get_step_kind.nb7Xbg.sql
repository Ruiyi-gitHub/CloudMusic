create function get_step_kind() returns INT(10)
BEGIN
  DECLARE result INTEGER DEFAULT -1;

  SELECT step_kind FROM debuggings WHERE id = @debug_id INTO result;
  RETURN result;
END;

