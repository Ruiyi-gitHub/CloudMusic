create function get_value() returns VARCHAR(2000)
BEGIN
  RETURN 'NYI';
END;

