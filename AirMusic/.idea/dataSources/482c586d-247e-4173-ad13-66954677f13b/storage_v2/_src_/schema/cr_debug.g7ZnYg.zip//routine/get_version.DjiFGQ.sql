create function get_version() returns INT(10)
BEGIN
  RETURN 100407;
END;

