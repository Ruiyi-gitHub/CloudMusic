create procedure leave_module(IN in_stack_depth INTEGER(10))
BEGIN
  IF (@debug_id > 0) THEN
    DELETE FROM callstack WHERE debug_id = @debug_id AND stack_depth > in_stack_depth;

    SET @stack_depth = in_stack_depth;
    UPDATE info SET stack_depth = in_stack_depth WHERE debug_id = @debug_id;

    IF (@stack_depth <= 0) THEN
      UPDATE info SET break_reason = 25 WHERE debug_id = @debug_id;
    END IF;
  END IF;
END;

