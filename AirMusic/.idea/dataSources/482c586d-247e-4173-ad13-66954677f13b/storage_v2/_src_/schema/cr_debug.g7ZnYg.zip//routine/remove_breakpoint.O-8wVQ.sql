create procedure remove_breakpoint(IN breakpoint_no INTEGER(10))
BEGIN
  DELETE FROM breakpoints WHERE ID = breakpoint_no;
END;

