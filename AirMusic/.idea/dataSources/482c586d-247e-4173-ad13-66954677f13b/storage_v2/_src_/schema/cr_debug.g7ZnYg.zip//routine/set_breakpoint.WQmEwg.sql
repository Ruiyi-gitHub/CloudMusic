create procedure set_breakpoint(IN in_module_name VARCHAR(300), IN in_module_owner VARCHAR(300),
                                IN in_module_type INTEGER(10), IN in_line INTEGER(10), IN in_pos INTEGER(10),
                                IN out_br_no INTEGER(10))
BEGIN
  DECLARE module_exists INTEGER DEFAULT -1;

  IF (in_module_type = 7 OR in_module_type = 8) THEN
    SELECT COUNT(routine_name) INTO module_exists FROM information_schema.routines WHERE routine_name = in_module_name AND
      routine_schema = in_module_owner; 
  ELSEIF (in_module_type = 12) THEN
    SELECT COUNT(trigger_name) INTO module_exists FROM information_schema.triggers WHERE trigger_name = in_module_name AND
      trigger_schema = in_module_owner;
  END IF;

  SET out_br_no := -1;
  IF (module_exists <> 0) THEN
    DELETE FROM breakpoints WHERE module_name = in_module_name AND module_owner = in_module_owner AND module_type = in_module_type 
      AND line = in_line AND pos = in_pos AND debug_id = @debug_id;
    INSERT INTO breakpoints (module_name, module_owner, module_type, line, pos, debug_id) VALUES
      (in_module_name, in_module_owner, in_module_type, in_line, in_pos, @debug_id);
    SELECT LAST_INSERT_ID() INTO out_br_no;
  END IF;
END;

