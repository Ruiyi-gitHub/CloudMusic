create procedure set_value(IN var VARCHAR(300), IN val VARCHAR(2000))
BEGIN

END;

