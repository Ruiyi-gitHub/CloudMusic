create procedure synchronize(IN out_unit_name VARCHAR(300), IN out_unit_owner VARCHAR(300),
                             IN out_unit_type INTEGER(10), IN out_stack_depth INTEGER(10),
                             IN out_start_line INTEGER(10), IN out_end_line INTEGER(10), IN out_start_pos INTEGER(10),
                             IN out_end_pos INTEGER(10), IN out_break_reason INTEGER(10))
BEGIN
  DECLARE second_lock VARCHAR(200);
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET out_break_reason = 0;

  IF (IS_USED_LOCK(@debug_id) = CONNECTION_ID()) THEN
    SET second_lock = CONCAT(@debug_id, 'second');
  ELSE
    SET second_lock = @debug_id;
  END IF;

  IF (IS_FREE_LOCK(second_lock) > 0) THEN
    SELECT module_name, module_owner,  module_type, c.stack_depth, start_line, end_line, start_pos, end_pos, break_reason
      FROM callstack c, debuggings d, info i 
      WHERE c.debug_id = @debug_id AND d.id = @debug_id AND i.debug_id = @debug_id AND c.stack_depth = i.stack_depth
      INTO out_unit_name, out_unit_owner, out_unit_type, out_stack_depth, out_start_line, out_end_line, out_start_pos, 
        out_end_pos, out_break_reason;
  END IF;
END;

