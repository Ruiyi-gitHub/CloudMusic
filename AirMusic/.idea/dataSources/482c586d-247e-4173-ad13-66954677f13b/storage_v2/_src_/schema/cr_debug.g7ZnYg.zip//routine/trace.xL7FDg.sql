create procedure trace(IN in_start_line INTEGER(10), IN in_end_line INTEGER(10), IN in_start_pos INTEGER(10),
                       IN in_end_pos INTEGER(10), IN in_stack_depth INTEGER(10))
Trace: BEGIN
  DECLARE step_kind, estimated_depth INTEGER DEFAULT -1;
  DECLARE main_lock VARCHAR(200);
  DECLARE cnt INT DEFAULT 0;

  IF (@debug_id > 0) THEN
    IF (in_stack_depth < @stack_depth) THEN
      CALL leave_module(in_stack_depth);
    END IF;

    UPDATE callstack SET start_line = in_start_line, end_line = in_end_line, 
      start_pos = in_start_pos, end_pos = in_end_pos WHERE debug_id = @debug_id AND stack_depth = @stack_depth;

    SET step_kind := get_step_kind();

    IF (step_kind = 1100) THEN
      UPDATE info SET break_reason = 25 WHERE debug_id = @debug_id;
      UPDATE debuggings SET cr_debug_terminated = 1 WHERE id = @debug_id;
    END IF;

    IF (step_kind = 2 or step_kind = 3) THEN
      SELECT d.estimated_depth FROM debuggings d WHERE id = @debug_id INTO estimated_depth;
      
      IF (@stack_depth > estimated_depth AND check_breakpoint() = 0) THEN
        LEAVE Trace;
      END IF;

    ELSEIF (step_kind = 4 AND check_breakpoint() = 0) THEN
      LEAVE Trace;
    END IF;

    UPDATE info SET break_reason = step_kind WHERE debug_id = @debug_id;

    IF (IS_USED_LOCK(@debug_id) = CONNECTION_ID()) THEN
      SET main_lock = CONCAT(@debug_id, 'second');
    ELSE
      SET main_lock = @debug_id;
    END IF;

    DO GET_LOCK(main_lock, 3600);
  END IF;
END;

