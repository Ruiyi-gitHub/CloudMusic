create procedure update_system_calls(IN in_query_type INTEGER(10))
begin
  IF (in_query_type = 101) THEN
    SET @debug_found_rows := FOUND_ROWS();
  ELSEIF(in_query_type = 102) THEN
    SET @debug_row_count := ROW_COUNT();
	SET @debug_last_insert_id := LAST_INSERT_ID();
  ELSEIF (in_query_type = 103 OR in_query_type = 104) THEN
	SET @debug_row_count := ROW_COUNT();
  ELSE
	SET @debug_row_count := ROW_COUNT();
	SET @debug_found_rows := FOUND_ROWS();
	SET @debug_last_insert_id := LAST_INSERT_ID();
  END IF;
END;

