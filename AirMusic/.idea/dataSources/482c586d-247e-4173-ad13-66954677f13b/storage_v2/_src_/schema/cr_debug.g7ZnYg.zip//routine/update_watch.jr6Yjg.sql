create procedure update_watch(IN in_watch_name VARCHAR(200), IN in_watch_value VARCHAR(65535))
BEGIN
  CALL update_watch2(in_watch_name, in_watch_value, @stack_depth);
END;

