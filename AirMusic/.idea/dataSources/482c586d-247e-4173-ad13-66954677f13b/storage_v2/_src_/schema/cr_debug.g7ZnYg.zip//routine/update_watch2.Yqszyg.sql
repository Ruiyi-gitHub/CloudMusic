create procedure update_watch2(IN in_watch_name VARCHAR(200), IN in_watch_value VARCHAR(65535),
                               IN in_stack_depth INTEGER(10))
BEGIN
  DECLARE watch_id INT DEFAULT -1;
  IF (@debug_id > 0) THEN

    SELECT id INTO watch_id 
      FROM watches 
      WHERE watch_name = in_watch_name AND stack_depth = in_stack_depth AND debug_id = @debug_id;

    IF (watch_id < 0) THEN
      INSERT INTO watches (watch_name, watch_value, stack_depth, debug_id) 
        VALUES (in_watch_name, in_watch_value, in_stack_depth, @debug_id);
    ELSE
      UPDATE watches SET watch_name = in_watch_name, watch_value = in_watch_value, debug_id = @debug_id
        WHERE ID = watch_id;
    END IF;
  END IF;
END;

