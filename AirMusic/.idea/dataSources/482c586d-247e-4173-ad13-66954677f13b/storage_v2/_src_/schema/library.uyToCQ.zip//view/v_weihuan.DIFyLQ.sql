create view v_weihuan as
    /* ALGORITHM=UNDEFINED */
select `library`.`reader`.`rName`    AS `rName`,
       `library`.`book`.`bName`      AS `bName`,
       `library`.`borrow`.`willDate` AS `willDate`
from ((`library`.`borrow` join `library`.`book` on ((`library`.`book`.`bid` = `library`.`borrow`.`nif`)))
         join `library`.`reader` on ((`library`.`reader`.`Rid` = `library`.`borrow`.`rid`)))
order by `library`.`reader`.`rName`;

