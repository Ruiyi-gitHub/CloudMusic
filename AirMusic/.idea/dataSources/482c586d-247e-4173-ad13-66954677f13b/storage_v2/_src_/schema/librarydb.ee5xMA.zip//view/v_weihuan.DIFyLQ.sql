create view v_weihuan as
    /* ALGORITHM=UNDEFINED */
select `librarydb`.`reader`.`rName`    AS `rName`,
       `librarydb`.`book`.`bName`      AS `bName`,
       `librarydb`.`borrow`.`willDate` AS `willDate`
from ((`librarydb`.`borrow` join `librarydb`.`book` on ((`librarydb`.`book`.`bid` = `librarydb`.`borrow`.`nif`)))
         join `librarydb`.`reader` on ((`librarydb`.`reader`.`Rid` = `librarydb`.`borrow`.`rid`)))
order by `librarydb`.`reader`.`rName`;

