create view v_subject_avgresult as
    /* ALGORITHM=UNDEFINED */
select `myschool`.`student`.`studentName`       AS `studentName`,
       `myschool`.`subject`.`subjectName`       AS `subjectName`,
       avg(`myschool`.`result`.`studentResult`) AS `AVG(result.studentResult)`
from ((`myschool`.`student` join `myschool`.`result` on ((`myschool`.`result`.`studentNo` = `myschool`.`student`.`studentNo`)))
         join `myschool`.`subject` on ((`myschool`.`result`.`subjectNo` = `myschool`.`subject`.`subjectNo`)))
group by `myschool`.`student`.`studentName`, `myschool`.`subject`.`subjectName`;

