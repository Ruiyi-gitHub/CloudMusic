create view view_student_result as
    /* ALGORITHM=UNDEFINED */
select `myschool`.`student`.`studentName`  AS `姓名`,
       `myschool`.`student`.`studentNo`    AS `学号`,
       `myschool`.`result`.`studentResult` AS `成绩`,
       `myschool`.`subject`.`subjectName`  AS `课程名称`,
       `myschool`.`result`.`examDate`      AS `考试日期`
from ((`myschool`.`student` join `myschool`.`result` on ((`myschool`.`student`.`studentNo` = `myschool`.`result`.`studentNo`)))
         join `myschool`.`subject` on ((`myschool`.`result`.`subjectNo` = `myschool`.`subject`.`subjectNo`)))
where ((`myschool`.`subject`.`subjectNo` = (select `myschool`.`subject`.`subjectNo` AS `subjectNo`
                                            from `myschool`.`subject`
                                            where (`myschool`.`subject`.`subjectName` = _gbk'Logic Java'))) and
       (`myschool`.`result`.`examDate` = (select max(`myschool`.`result`.`examDate`) AS `MAX(examDate)`
                                          from `myschool`.`result`
                                                   join `myschool`.`subject`
                                          where ((`myschool`.`result`.`subjectNo` = `myschool`.`subject`.`subjectNo`) and
                                                 (`myschool`.`subject`.`subjectName` = _gbk'Logic Java')))));

