create view student_view as
    /* ALGORITHM=UNDEFINED */
select count(`schooldb`.`score`.`cid`) AS `考试科目数`,
       `schooldb`.`student`.`sid`      AS `学生编号`,
       `schooldb`.`student`.`stuName`  AS `学生姓名`,
       sum(`schooldb`.`score`.`score`) AS `各科总分`
from (`schooldb`.`student`
         join `schooldb`.`score` on ((`schooldb`.`score`.`sid` = `schooldb`.`student`.`sid`)))
group by `schooldb`.`student`.`sid`
having (count(`schooldb`.`score`.`cid`) > 2);

